from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import render,redirect
from companyapp.models import Teacher,Feedback
def login(request):
    if request.method=="POST":
      username=request.POST["txtname"]
      password=request.POST["txtpass"]
      s = Teacher.objects.filter(name=username,password=password)
      if(s.count()>0):
        request.session["tid"] = username
        return redirect('/teacher/dashboard')
      else:
        return HttpResponse("Invalid userid and password")
    else:
        return render(request,"teacher/login.html")    
def logout(request):
    del request.session["tid"]
    return redirect('/teacher')
def dashboard(request):
    if(request.session.has_key('tid')):
        obj = Feedback.objects.filter(feedto=request.session['tid'])
        return render(request,"teacher/dashboard.html",{'res':obj,'key':request.session['tid']})
    else:
         return redirect('/teacher')