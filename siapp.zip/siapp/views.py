from django.shortcuts import render
from django.http import HttpResponse
def index(request): # it is the reference HTTpRequest
    if request.method=="POST":
        p = request.POST["txtp"]
        r = request.POST["txtr"]
        t = request.POST["txtt"]
        si = (float(p)*float(r)*float(t))/100
        return render(request,"si.html",{"key":si});
    else:    
      return render(request,"si.html")
def square(request):
    if request.method=="POST":
        s = float(request.POST["txtnum"])
        sq = s*s;
        return render(request,"square.html",{"key":sq})

    else:
        return render(request,"square.html")          

