from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import Contact,Register,Feedback,Teacher
# Create your views here.
def home(request):
    if request.method=="POST":
        insertcode(request)
        return render(request,"companyapp/index.html",{"key":"Data Inserted Successfully"})
    return render(request,"companyapp/index.html")
def about(request):
    return render(request,"companyapp/about.html")  
def service(request):
    return render(request,"companyapp/service.html")   
def portfolio(request):
    return render(request,"companyapp/portfolio.html")
def contact(request):
    if request.method=="POST":
        insertcode()
        return render(request,"companyapp/contact.html",{"key":"Data Inserted Successfully"})
    return render(request,"companyapp/contact.html")       
def loginreg(request):
    if request.method=="POST":
      username=request.POST["txtname"]
      password=request.POST["txtpass"]
      phone=request.POST["txtphone"]
      email=request.POST["txtemail"]
      obj = Register(username=username,password=password,mobile=phone,email=email)
      obj.save()
      return render(request,"companyapp/reg.html",{"key":"reg successfully"})
    return render(request,"companyapp/reg.html")
def insertcode(request):
     name=request.POST["txtname"]
     email=request.POST["txtemail"]
     phone=request.POST["txtphone"]
     message=request.POST["txtmsg"]
     obj = Contact(name=name,email=email,phone=phone,message=message)
     obj.save()
def login(request):
    if request.method=="POST":
      username=request.POST["txtname"]
      password=request.POST["txtpass"]
      s = Register.objects.filter(email=username,password=password)
      if(s.count()>0):
        request.session["uid"] = username
        return redirect('dashboard')
      else:
        return HttpResponse("Invalid userid and password")  
    return render(request,"companyapp/login.html")     
def dashboard(request):
    if(request.session.has_key('uid')):
       teacher= Teacher.objects.all()
       if request.method=="POST":
         obj = Feedback(feedto=request.POST['feedto'],feedby=request.session['uid'],feeddesc=request.POST['feeddesc'],feedrate=int(request.POST['rate']))
         obj.save()
         return render(request,"companyapp/dashboard.html",{"key":request.session["uid"],"res":"feedback submitted successfully","tdata":teacher})

       return render(request,"companyapp/dashboard.html",{"key":request.session["uid"],"tdata":teacher}) 
    else:
       return redirect('login')    
def logout(request):
     del request.session["uid"]
     return redirect('login')
def viewfeed(request):
    feed = Feedback.objects.filter(feedby=request.session['uid'])
    return render(request,"companyapp/viewfeed.html",{"res":feed,"key":request.session["uid"]})