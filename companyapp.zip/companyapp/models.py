from django.db import models
class Student(models.Model):
       rno = models.CharField(max_length=10)
       name = models.CharField(max_length=10)
       branch=models.CharField(max_length=50)
       fees = models.CharField(max_length=10)
       def __str__(self):
            return self.rno + " " + self.name + " " + self.branch + " " + self.fees

class Feedback(models.Model):
     feedto=models.CharField(max_length=10)
     feedby=models.CharField(max_length=10)
     feeddesc=models.CharField(max_length=300)
     feedrate=models.IntegerField()
     def __str__(self):
            return " Teacher: " + self.feedto + " Student: " + self.feedby + " Desc: " + self.feeddesc + " Rating: " + str(self.feedrate)
class Teacher(models.Model):
       name = models.CharField(max_length=10)
       password=models.CharField(max_length=20,default='')
       branch=models.CharField(max_length=50)
       salary = models.IntegerField(max_length=10)

       def __str__(self):
            return self.name + " " + self.branch + " " + str(self.salary)
class Register(models.Model):
       username = models.CharField(max_length=10)
       password=models.CharField(max_length=50)
       mobile = models.CharField(max_length=10)
       email=models.CharField(max_length=50)
       def __str__(self):
            return self.username + " " + self.password + " " + str(self.mobile) + self.email
class Contact(models.Model):
     name=models.CharField(max_length=30)
     email=models.CharField(max_length=50)
     phone=models.CharField(max_length=50)
     message=models.CharField(max_length=400)
     def __str__(self):
          return "name:"+self.name + " email:"+self.email+" phone:"+self.phone+" message"+self.message